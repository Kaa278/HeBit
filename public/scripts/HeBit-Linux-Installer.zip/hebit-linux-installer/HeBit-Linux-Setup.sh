#!/usr/bin/env bash
set -euo pipefail

BRAND="HeBit"
EXT_ID="RooVeterinaryInc.roo-cline"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[1;34m'
CYAN='\033[1;36m'
NC='\033[0m'

clear

print_banner() {
  echo -e "${CYAN}"
  echo "██╗  ██╗███████╗██████╗ ██╗████████╗"
  echo "██║  ██║██╔════╝██╔══██╗██║╚══██╔══╝"
  echo "███████║█████╗  ██████╔╝██║   ██║   "
  echo "██╔══██║██╔══╝  ██╔══██╗██║   ██║   "
  echo "██║  ██║███████╗██████╔╝██║   ██║   "
  echo "╚═╝  ╚═╝╚══════╝╚═════╝ ╚═╝   ╚═╝   "
  echo -e "${NC}"
  echo -e "${BLUE}        HeBit Roo Code Installer${NC}"
  echo ""
}

loading_bar() {
  local duration=${1:-2}
  local width=30
  local i

  echo -ne "${GREEN}Loading:${NC} ["
  for ((i=0; i<width; i++)); do
    echo -ne "#"
    sleep $(awk "BEGIN {print $duration/$width}")
  done
  echo "] Done"
}

step() {
  echo ""
  echo -e "${BLUE}▶ $1${NC}"
  sleep 0.4
}

success() {
  echo -e "${GREEN}✔ $1${NC}"
}

print_banner
loading_bar 1

detect_editors() {
  local found=()

  if command -v cursor >/dev/null 2>&1; then
    found+=("Cursor|cursor|$HOME/.config/Cursor")
  fi

  if command -v code >/dev/null 2>&1; then
    found+=("VS Code|code|$HOME/.config/Code")
  fi

  if command -v code-insiders >/dev/null 2>&1; then
    found+=("VS Code Insiders|code-insiders|$HOME/.config/Code - Insiders")
  fi

  if command -v windsurf >/dev/null 2>&1; then
    found+=("Windsurf|windsurf|$HOME/.config/Windsurf")
  fi

  if command -v antigravity >/dev/null 2>&1; then
    found+=("Antigravity|antigravity|$HOME/.config/Antigravity")
  fi

  printf '%s\n' "${found[@]}"
}

step "Mendeteksi editor"
mapfile -t EDITORS < <(detect_editors)

if [ "${#EDITORS[@]}" -eq 0 ]; then
  echo -e "${RED}Tidak ada editor terdeteksi.${NC}"
  echo "Install salah satu editor berikut dulu:"
  echo "- VS Code"
  echo "- Cursor"
  echo "- Windsurf"
  exit 1
fi

if [ "${#EDITORS[@]}" -eq 1 ]; then
  SELECTED="${EDITORS[0]}"
else
  echo ""
  echo "Editor ditemukan:"
  echo ""

  idx=1
  for item in "${EDITORS[@]}"; do
    name="$(echo "$item" | cut -d'|' -f1)"
    echo "[$idx] $name"
    idx=$((idx+1))
  done

  echo ""
  while true; do
    read -r -p "Pilih editor [1-${#EDITORS[@]}]: " choice
    if [[ "$choice" =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le "${#EDITORS[@]}" ]; then
      SELECTED="${EDITORS[$((choice-1))]}"
      break
    fi
    echo "Pilihan tidak valid"
  done
fi

EDITOR_NAME="$(echo "$SELECTED" | cut -d'|' -f1)"
EDITOR_CMD="$(echo "$SELECTED" | cut -d'|' -f2)"
EDITOR_CONFIG="$(echo "$SELECTED" | cut -d'|' -f3)"

success "Menggunakan $EDITOR_NAME"

step "Menginstall Roo Code"
"$EDITOR_CMD" --install-extension "$EXT_ID" >/dev/null 2>&1 || {
  echo -e "${RED}Gagal install Roo Code.${NC}"
  exit 1
}
success "Roo Code berhasil diinstall"

GLOBAL_STORAGE="$EDITOR_CONFIG/User/globalStorage"
ROO_DIR="$GLOBAL_STORAGE/rooveterinaryinc.roo-cline"
ROO_SETTINGS="$ROO_DIR/settings"

step "Menyiapkan konfigurasi"
mkdir -p "$ROO_SETTINGS"
mkdir -p "$ROO_DIR/rules"
mkdir -p "$ROO_DIR/skills"

python3 "$SCRIPT_DIR/tools/render_mcp.py" \
  "$SCRIPT_DIR/config/settings/mcp_settings.template.json" \
  "$ROO_SETTINGS/mcp_settings.json" \
  "$HOME" \
  "" >/dev/null 2>&1 || true

cp "$SCRIPT_DIR/config/settings/custom_modes.yaml" "$ROO_SETTINGS/custom_modes.yaml"
cp -f "$SCRIPT_DIR/config/rules/"*.md "$ROO_DIR/rules/" 2>/dev/null || true
cp -f "$SCRIPT_DIR/config/skills/"*.md "$ROO_DIR/skills/" 2>/dev/null || true

success "Custom modes & rules berhasil dipasang"

step "Finishing"
loading_bar 1

clear
print_banner

echo -e "${GREEN}Setup selesai.${NC}"
echo ""
echo "Yang sudah dipasang:"
echo "- Roo Code extension"
echo "- MCP settings"
echo "- Custom modes"
echo "- Rules & skills"
echo ""
echo "Langkah selanjutnya di Roo Code:"
echo "1. Buka Roo Code"
echo "2. Masukkan Base URL"
echo "3. Masukkan API Key"
echo "4. Pilih model"
echo ""
echo -e "${CYAN}Happy coding with HeBit 🚀${NC}"
