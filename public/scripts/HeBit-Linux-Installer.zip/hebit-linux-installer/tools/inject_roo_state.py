#!/usr/bin/env python3
import argparse
import json
import shutil
import sqlite3
from pathlib import Path
from datetime import datetime

def try_json_loads(value):
    if value is None:
        return None
    if isinstance(value, bytes):
        try:
            value = value.decode("utf-8")
        except Exception:
            return None
    if not isinstance(value, str):
        return None
    value = value.strip()
    if not value:
        return None
    try:
        return json.loads(value)
    except Exception:
        return None

def json_dumps(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))

def patch_object(obj, args, instructions, custom_modes_text):
    changed = False

    if isinstance(obj, dict):
        # Common/simple keys. Roo Code versions may differ, so this is best-effort.
        possible_instruction_keys = [
            "customInstructions",
            "globalCustomInstructions",
            "customSupportPrompts",
            "systemPrompt",
            "globalInstructions",
        ]
        for k in possible_instruction_keys:
            if k in obj and isinstance(obj[k], str):
                obj[k] = instructions
                changed = True

        provider_pairs = {
            "apiProvider": "openai-compatible",
            "selectedProvider": "openai-compatible",
            "openAiBaseUrl": args.base_url,
            "openAIBaseUrl": args.base_url,
            "baseUrl": args.base_url,
            "baseURL": args.base_url,
            "apiKey": args.api_key,
            "openAiApiKey": args.api_key,
            "openAIApiKey": args.api_key,
            "model": args.model,
            "apiModelId": args.model,
            "modelId": args.model,
        }

        for k, v in provider_pairs.items():
            if k in obj:
                obj[k] = v
                changed = True

        # Add HeBit metadata without deleting existing values.
        if "hebit" not in obj and any(str(x).lower().find("roo") >= 0 for x in obj.keys()):
            obj["hebit"] = {
                "brand": args.brand,
                "baseUrl": args.base_url,
                "model": args.model,
            }
            changed = True

        for key, val in list(obj.items()):
            sub_changed = patch_object(val, args, instructions, custom_modes_text)
            changed = changed or sub_changed

    elif isinstance(obj, list):
        for item in obj:
            sub_changed = patch_object(item, args, instructions, custom_modes_text)
            changed = changed or sub_changed

    return changed

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--db", required=True)
    p.add_argument("--brand", required=True)
    p.add_argument("--base-url", required=True)
    p.add_argument("--api-key", required=True)
    p.add_argument("--model", required=True)
    p.add_argument("--instructions-file", required=True)
    p.add_argument("--custom-modes-file", required=True)
    args = p.parse_args()

    db = Path(args.db)
    if not db.exists():
        print(f"state.vscdb tidak ditemukan: {db}")
        return

    instructions = Path(args.instructions_file).read_text()
    custom_modes_text = Path(args.custom_modes_file).read_text()

    backup = db.with_suffix(db.suffix + f".hebit-backup-{datetime.now().strftime('%Y%m%d%H%M%S')}")
    shutil.copy2(db, backup)
    print(f"backup: {backup}")

    conn = sqlite3.connect(str(db))
    cur = conn.cursor()

    try:
        rows = cur.execute("SELECT key, value FROM ItemTable").fetchall()
    except Exception as e:
        print(f"gagal baca ItemTable: {e}")
        conn.close()
        return

    patched = 0
    dumped = []

    for key, value in rows:
        key_s = str(key)
        value_s = value.decode("utf-8", "ignore") if isinstance(value, bytes) else str(value)

        if "roo" in key_s.lower() or "cline" in key_s.lower() or "rooveterinary" in key_s.lower():
            dumped.append((key_s, value_s[:500]))

        obj = try_json_loads(value)
        if obj is None:
            # Patch plain string values for global instructions-like keys.
            lower_key = key_s.lower()
            if ("roo" in lower_key or "cline" in lower_key or "rooveterinary" in lower_key) and ("instruction" in lower_key or "prompt" in lower_key):
                cur.execute("UPDATE ItemTable SET value=? WHERE key=?", (instructions, key))
                patched += 1
            continue

        lower = (key_s + " " + value_s[:1000]).lower()
        if "roo" not in lower and "cline" not in lower and "rooveterinary" not in lower:
            continue

        changed = patch_object(obj, args, instructions, custom_modes_text)
        if changed:
            cur.execute("UPDATE ItemTable SET value=? WHERE key=?", (json_dumps(obj), key))
            patched += 1

    conn.commit()
    conn.close()

    dump_path = db.parent / "hebit_roo_state_keys_dump.txt"
    with dump_path.open("w") as f:
        for k, v in dumped:
            f.write(f"KEY: {k}\nVALUE_PREVIEW: {v}\n\n")

    print(f"patched rows: {patched}")
    print(f"roo key dump: {dump_path}")
    print("Catatan: patch state.vscdb bersifat best-effort karena format internal Roo Code bisa berubah.")

if __name__ == "__main__":
    main()
