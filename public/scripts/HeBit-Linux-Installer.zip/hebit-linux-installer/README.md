# HeBit Linux Installer

File utama:

```bash
./HeBit-Linux-Setup.sh
```

Cara pakai:

```bash
unzip HeBit-Linux-Installer.zip
cd hebit-linux-installer
chmod +x HeBit-Linux-Setup.sh
./HeBit-Linux-Setup.sh
```

Kalau terdeteksi lebih dari 1 IDE, installer akan menampilkan pilihan angka.

Yang dilakukan installer:
1. Detect Cursor / VS Code / VS Code Insiders / Windsurf / Antigravity.
2. User pilih IDE jika lebih dari satu.
3. Install Roo Code extension.
4. Copy MCP config.
5. Copy custom modes Kathlyn:
   - Ask
   - Code
   - Architect
   - Debug
   - Orchestrator
6. Copy rules dan skills.
7. Simpan provider template HeBit:
   - Base URL: https://hellobit-1.tailc64650.ts.net/v1
   - Model: cx/gpt-5.5-high
8. Best-effort patch `state.vscdb`.

Catatan penting:
- Patch `state.vscdb` bersifat best-effort karena format internal Roo Code bisa berubah.
- Installer membuat backup `state.vscdb` sebelum patch.
- Kalau provider belum otomatis tampil, file provider template ada di:
  `User/globalStorage/rooveterinaryinc.roo-cline/settings/hebit_provider.json`
