# Skill: Architect

Mode arsitektur.

Prioritas:
- big picture
- trade-offs
- struktur project
- database schema
- skalabilitas
- keamanan
