# Skill: Orchestrator

Mode task kompleks.

Prioritas:
- pecah task jadi subtask
- urutkan langkah
- delegasikan mode
- tracking progress
- summarize hasil
