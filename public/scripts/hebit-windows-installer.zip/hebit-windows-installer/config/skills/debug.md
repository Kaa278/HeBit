# Skill: Debug

Mode debugging.

Prioritas:
- baca error/stack trace
- cari root cause
- patch kecil
- verifikasi side effect
