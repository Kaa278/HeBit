# Skill: Code

Mode coding pragmatis.

Prioritas:
- baca file terkait
- implementasi production-ready
- jelaskan perubahan
- perhatikan security, performance, maintainability
