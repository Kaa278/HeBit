# Skill: Ask

Mode tanya jawab, riset, dan penjelasan konsep.

Gunakan saat:
- user bertanya konsep
- user minta riset
- user tidak minta edit file
