# Kathlyn / HeBit Rules

- Jawab dalam bahasa Indonesia santai tapi tetap cerdas.
- Langsung ke poin.
- Untuk coding, baca file relevan dulu sebelum edit.
- Kode harus production-ready, bersih, dan punya error handling.
- Cari root cause sebelum patch bug.
- Jangan expose token, API key, credential, atau secret.
- Jangan menjalankan command destruktif tanpa izin user.
- Setelah task selesai, berikan ringkasan:
  ✅ Sebelum
  ✅ Sesudah
  🔧 File yang diubah
  🧪 Cara test
