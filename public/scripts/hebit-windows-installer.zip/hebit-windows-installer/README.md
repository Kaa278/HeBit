# HeBit Windows Installer

Installer otomatis untuk mengkonfigurasi Roo Code dengan HeBit API di Windows.

## Cara Pakai

1. **Extract** file ZIP ini ke folder mana saja
2. **Double-click** `HeBit-Windows-Setup.bat`
3. Kalau muncul popup "Windows protected your PC" → klik **More info** → **Run anyway**
4. Ikuti instruksi di terminal

## Yang Diinstall Otomatis

- Roo Code extension di editor kamu
- Custom modes: Ask, Code, Architect, Debug, Orchestrator
- Rules & skills HeBit
- MCP settings (memerlukan Python)

## Editor yang Didukung

- VS Code
- VS Code Insiders
- Cursor
- Windsurf
- Antigravity

## Setelah Install

Buka Roo Code dan masukkan:
- **Base URL**: dari admin HeBit
- **API Key**: dari admin HeBit (via WhatsApp)
- **Model**: sesuai paket yang dibeli

## Catatan

- Script ini tidak memerlukan internet untuk berjalan
- Hanya install extension Roo Code yang memerlukan koneksi internet
- Python opsional (untuk MCP settings). Download di https://python.org
