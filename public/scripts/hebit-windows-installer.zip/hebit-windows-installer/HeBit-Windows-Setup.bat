@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1
title HeBit Installer

:: ============================================================
::  HeBit Windows Installer
::  Double-click untuk jalankan. Tidak perlu konfigurasi manual.
:: ============================================================

set "SCRIPT_DIR=%~dp0"
set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"
set "EXT_ID=RooVeterinaryInc.roo-cline"
set "BRAND=HeBit"

cls
call :print_banner
call :loading_bar

:: ============================================================
::  DETEKSI EDITOR
:: ============================================================

echo.
echo [*] Mendeteksi editor yang terinstall...
echo.

set "EDITOR_COUNT=0"
set "EDITOR_NAMES="
set "EDITOR_CMDS="
set "EDITOR_CONFIGS="

:: Cek VS Code
where code >nul 2>&1
if !errorlevel! == 0 (
    set /a EDITOR_COUNT+=1
    set "EDITOR_NAME_!EDITOR_COUNT!=VS Code"
    set "EDITOR_CMD_!EDITOR_COUNT!=code"
    set "EDITOR_CONFIG_!EDITOR_COUNT!=%APPDATA%\Code"
)

:: Cek VS Code Insiders
where code-insiders >nul 2>&1
if !errorlevel! == 0 (
    set /a EDITOR_COUNT+=1
    set "EDITOR_NAME_!EDITOR_COUNT!=VS Code Insiders"
    set "EDITOR_CMD_!EDITOR_COUNT!=code-insiders"
    set "EDITOR_CONFIG_!EDITOR_COUNT!=%APPDATA%\Code - Insiders"
)

:: Cek Cursor
where cursor >nul 2>&1
if !errorlevel! == 0 (
    set /a EDITOR_COUNT+=1
    set "EDITOR_NAME_!EDITOR_COUNT!=Cursor"
    set "EDITOR_CMD_!EDITOR_COUNT!=cursor"
    set "EDITOR_CONFIG_!EDITOR_COUNT!=%APPDATA%\Cursor"
)

:: Cek Windsurf
where windsurf >nul 2>&1
if !errorlevel! == 0 (
    set /a EDITOR_COUNT+=1
    set "EDITOR_NAME_!EDITOR_COUNT!=Windsurf"
    set "EDITOR_CMD_!EDITOR_COUNT!=windsurf"
    set "EDITOR_CONFIG_!EDITOR_COUNT!=%APPDATA%\Windsurf"
)

:: Cek Antigravity
where antigravity >nul 2>&1
if !errorlevel! == 0 (
    set /a EDITOR_COUNT+=1
    set "EDITOR_NAME_!EDITOR_COUNT!=Antigravity"
    set "EDITOR_CMD_!EDITOR_COUNT!=antigravity"
    set "EDITOR_CONFIG_!EDITOR_COUNT!=%APPDATA%\Antigravity"
)

:: Fallback: cek di path default kalau where gagal

:: VS Code fallback
if !EDITOR_COUNT! == 0 (
    if exist "%LOCALAPPDATA%\Programs\Microsoft VS Code\bin\code.cmd" (
        set /a EDITOR_COUNT+=1
        set "EDITOR_NAME_!EDITOR_COUNT!=VS Code"
        set "EDITOR_CMD_!EDITOR_COUNT!=%LOCALAPPDATA%\Programs\Microsoft VS Code\bin\code.cmd"
        set "EDITOR_CONFIG_!EDITOR_COUNT!=%APPDATA%\Code"
    )
)

:: Cursor fallback
if !EDITOR_COUNT! == 0 (
    if exist "%LOCALAPPDATA%\Programs\cursor\resources\app\bin\cursor.cmd" (
        set /a EDITOR_COUNT+=1
        set "EDITOR_NAME_!EDITOR_COUNT!=Cursor"
        set "EDITOR_CMD_!EDITOR_COUNT!=%LOCALAPPDATA%\Programs\cursor\resources\app\bin\cursor.cmd"
        set "EDITOR_CONFIG_!EDITOR_COUNT!=%APPDATA%\Cursor"
    )
)

if !EDITOR_COUNT! == 0 (
    echo.
    echo [X] Tidak ada editor terdeteksi.
    echo.
    echo     Install salah satu editor berikut dulu:
    echo     - VS Code    : https://code.visualstudio.com
    echo     - Cursor     : https://cursor.com
    echo     - Windsurf   : https://windsurf.com
    echo.
    pause
    exit /b 1
)

:: ============================================================
::  PILIH EDITOR
:: ============================================================

if !EDITOR_COUNT! == 1 (
    set "SELECTED_NAME=!EDITOR_NAME_1!"
    set "SELECTED_CMD=!EDITOR_CMD_1!"
    set "SELECTED_CONFIG=!EDITOR_CONFIG_1!"
    echo [✓] Editor ditemukan: !SELECTED_NAME!
    echo.
) else (
    echo     Editor yang ditemukan:
    echo.
    for /l %%i in (1,1,!EDITOR_COUNT!) do (
        echo     [%%i] !EDITOR_NAME_%%i!
    )
    echo.

    :choose_loop
    set /p "CHOICE=    Pilih editor [1-!EDITOR_COUNT!]: "
    if "!CHOICE!"=="" goto choose_loop
    if !CHOICE! LSS 1 goto choose_loop
    if !CHOICE! GTR !EDITOR_COUNT! goto choose_loop

    set "SELECTED_NAME=!EDITOR_NAME_%CHOICE%!"
    set "SELECTED_CMD=!EDITOR_CMD_%CHOICE%!"
    set "SELECTED_CONFIG=!EDITOR_CONFIG_%CHOICE%!"
    echo.
    echo [✓] Menggunakan: !SELECTED_NAME!
    echo.
)

:: ============================================================
::  INSTALL ROO CODE EXTENSION
:: ============================================================

echo [*] Menginstall Roo Code extension...
"!SELECTED_CMD!" --install-extension "%EXT_ID%" >nul 2>&1
if !errorlevel! neq 0 (
    echo [X] Gagal install Roo Code.
    echo     Pastikan editor sudah bisa dijalankan dari terminal.
    echo     Coba buka editor dulu, lalu jalankan script ini lagi.
    pause
    exit /b 1
)
echo [✓] Roo Code berhasil diinstall!
echo.

:: ============================================================
::  SIAPKAN DIREKTORI KONFIGURASI
:: ============================================================

set "GLOBAL_STORAGE=!SELECTED_CONFIG!\User\globalStorage"
set "ROO_DIR=!GLOBAL_STORAGE!\rooveterinaryinc.roo-cline"
set "ROO_SETTINGS=!ROO_DIR!\settings"

echo [*] Menyiapkan konfigurasi HeBit...

if not exist "!ROO_SETTINGS!" mkdir "!ROO_SETTINGS!"
if not exist "!ROO_DIR!\rules" mkdir "!ROO_DIR!\rules"
if not exist "!ROO_DIR!\skills" mkdir "!ROO_DIR!\skills"

:: ============================================================
::  COPY CONFIG FILES
:: ============================================================

:: Custom modes
copy /y "%SCRIPT_DIR%\config\settings\custom_modes.yaml" "!ROO_SETTINGS!\custom_modes.yaml" >nul

:: Rules
for %%f in ("%SCRIPT_DIR%\config\rules\*.md") do (
    copy /y "%%f" "!ROO_DIR!\rules\" >nul
)

:: Skills
for %%f in ("%SCRIPT_DIR%\config\skills\*.md") do (
    copy /y "%%f" "!ROO_DIR!\skills\" >nul
)

:: MCP settings via Python (jika Python tersedia)
where python >nul 2>&1
if !errorlevel! == 0 (
    python "%SCRIPT_DIR%\tools\render_mcp.py" ^
        "%SCRIPT_DIR%\config\settings\mcp_settings.template.json" ^
        "!ROO_SETTINGS!\mcp_settings.json" ^
        "%USERPROFILE%" ^
        "" >nul 2>&1
) else (
    where python3 >nul 2>&1
    if !errorlevel! == 0 (
        python3 "%SCRIPT_DIR%\tools\render_mcp.py" ^
            "%SCRIPT_DIR%\config\settings\mcp_settings.template.json" ^
            "!ROO_SETTINGS!\mcp_settings.json" ^
            "%USERPROFILE%" ^
            "" >nul 2>&1
    ) else (
        echo [!] Python tidak ditemukan, skip MCP settings.
        echo     Install dari https://python.org jika diperlukan.
    )
)

echo [✓] Custom modes ^& rules berhasil dipasang!
echo.

:: ============================================================
::  SELESAI
:: ============================================================

call :loading_bar
cls
call :print_banner

echo.
echo  Setup selesai!
echo.
echo  Yang sudah dipasang:
echo    - Roo Code extension
echo    - MCP settings
echo    - Custom modes (Ask, Code, Architect, Debug, Orchestrator)
echo    - Rules ^& skills
echo.
echo  Langkah selanjutnya di Roo Code:
echo    1. Buka Roo Code di editor kamu
echo    2. Masukkan Base URL : https://hellobit-1.tailc64650.ts.net/v1
echo    3. Masukkan API Key  : (dari WhatsApp admin HeBit)
echo    4. Pilih model       : sesuai paket kamu
echo.
echo  Happy coding with HeBit!
echo.
pause
exit /b 0

:: ============================================================
::  SUBROUTINE
:: ============================================================

:print_banner
echo.
echo   ██╗  ██╗███████╗██████╗ ██╗████████╗
echo   ██║  ██║██╔════╝██╔══██╗██║╚══██╔══╝
echo   ███████║█████╗  ██████╔╝██║   ██║
echo   ██╔══██║██╔══╝  ██╔══██╗██║   ██║
echo   ██║  ██║███████╗██████╔╝██║   ██║
echo   ╚═╝  ╚═╝╚══════╝╚═════╝ ╚═╝   ╚═╝
echo.
echo          HeBit Windows Installer
echo.
goto :eof

:loading_bar
set "BAR="
for /l %%i in (1,1,30) do (
    set "BAR=!BAR!#"
    <nul set /p "=."
    ping -n 1 -w 30 127.0.0.1 >nul 2>&1
)
echo.
goto :eof
