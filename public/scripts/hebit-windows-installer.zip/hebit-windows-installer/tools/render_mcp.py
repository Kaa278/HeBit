#!/usr/bin/env python3
import json
import sys
from pathlib import Path

if len(sys.argv) != 5:
    print("usage: render_mcp.py template out user_home tavily_key")
    sys.exit(1)

template, out, user_home, tavily_key = sys.argv[1:]
text = Path(template).read_text()
text = text.replace("${USER_HOME}", user_home)
text = text.replace("${TAVILY_API_KEY}", tavily_key or "")
Path(out).write_text(text)
print(f"wrote {out}")
